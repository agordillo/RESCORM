# True False Game React

True False Game React es un juego configurable creado con React y Redux por el GING (Grupo de Internet de Nueva Generación). 
El juego muestra al usuario sitios web (como iframes o como capturas de las webs originales) y el usuario tiene que elegir si son reales o falsas.
El juego da puntos por cada acierto y se comunica con el LMS (p.e. Moodle) para dejar la nota, con lo que este juego puede ser utilizado en cursos.


  
# Documentación
Visite la wiki para obtener documentación -> https://github.com/ging/true_false_game_react/wiki


 
# License

True False Game React is available under MIT License.

Este juego se ha desarrollado basandose en [RESCORM](https://github.com/agordillo/RESCORM)

