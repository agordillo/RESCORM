export const question_example = {
  "question_type":"multiple_choice",
  "value":"¿Cuáles de las siguientes afirmaciones son verdaderas?",
  "choices": [
    {
      "id":"1",
      "value":"Madrid es la capital de España.",
      "answer":true
    },{
      "id":"2",
      "value":"Turín es la capital de Italia.",
      "answer":false
    },{
      "id":"3",
      "value":"París es la capital de Francia.",
      "answer":true
    },{
      "id":"4",
      "value":"Manchester es la capital de Inglaterra.",
      "answer":false
    }
  ]
}